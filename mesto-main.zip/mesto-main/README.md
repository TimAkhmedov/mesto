# Проект: Место

### Обзор 4 курсовой работы

* Аддаптивная верстка на разрешениях: 320рх, 1280рх.
* Flexbox and Grid technologies.
* HTML, CSS and JS used.
* Used branches in Git due to project.

[Github page.](https://timakhmedov.github.io/mesto/index.html "Мой проект тут!")
